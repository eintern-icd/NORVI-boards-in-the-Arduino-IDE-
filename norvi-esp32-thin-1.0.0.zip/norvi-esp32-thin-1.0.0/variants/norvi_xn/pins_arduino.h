#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <stdint.h>
#include "soc/soc_caps.h"

#define USB_VID 0x303a
#define USB_PID 0x1001

// Some boards have too low voltage on this pin (board design bug)
// Use different pin with 3V and connect with 48
// and change this setup for the chosen pin (for example 38)

static const uint8_t TX = 43;
static const uint8_t RX = 44;

static const uint8_t SDA = 8;
static const uint8_t SCL = 9;

static const uint8_t SS = 10;
static const uint8_t MOSI = 11;
static const uint8_t MISO = 13;
static const uint8_t SCK = 12;

static const uint8_t A0 = 1;
static const uint8_t A1 = 2;
static const uint8_t A2 = 3;
static const uint8_t A3 = 4;
static const uint8_t A4 = 5;
static const uint8_t A5 = 6;
static const uint8_t A6 = 7;
static const uint8_t A7 = 8;
static const uint8_t A8 = 9;
static const uint8_t A9 = 10;
static const uint8_t A10 = 11;
static const uint8_t A11 = 12;
static const uint8_t A12 = 13;
static const uint8_t A13 = 14;
static const uint8_t A14 = 15;
static const uint8_t A15 = 16;
static const uint8_t A16 = 17;
static const uint8_t A17 = 18;
static const uint8_t A18 = 19;
static const uint8_t A19 = 20;

static const uint8_t T1 = 1;
static const uint8_t T2 = 2;
static const uint8_t T3 = 3;
static const uint8_t T4 = 4;
static const uint8_t T5 = 5;
static const uint8_t T6 = 6;
static const uint8_t T7 = 7;
static const uint8_t T8 = 8;
static const uint8_t T9 = 9;
static const uint8_t T10 = 10;
static const uint8_t T11 = 11;
static const uint8_t T12 = 12;
static const uint8_t T13 = 13;
static const uint8_t T14 = 14;


// ---- NORVI additions (NORVI XN-MAIN) ----
// No native-GPIO LED on NORVI X boards: the LEDs and push buttons are on the PCA9536 (0x41).
#define NORVI_XN 1
#define NORVI_PORT_RST   38   // set HIGH to wake PCA9536 / PCA9539
#define NORVI_ETH_CS      1
#define NORVI_ETH_RST     2
#define NORVI_ETH_INT     4
#define NORVI_SD_CS      42
#define NORVI_TFT_CS     45
#define NORVI_TFT_DC     46
#define NORVI_TFT_RST    47
#define NORVI_TOUCH_RST  47
#define NORVI_TOUCH_INT  48
#define NORVI_RS485_TX   15
#define NORVI_RS485_RX   16
#define NORVI_UART1_TX   17
#define NORVI_UART1_RX   18
#define NORVI_I2C_TOUCH   0x15
#define NORVI_I2C_PCA9536 0x41
#define NORVI_I2C_RTC     0x68
#define NORVI_I2C_PCA9539 0x75
// PCA9536 pin numbers (LEDs are active LOW)
#define NORVI_PB1   0
#define NORVI_LED_ERROR 1   // P1 = ERROR (per X1/X2/X3 datasheets)
#define NORVI_LED_RUN   2   // P2 = RUN
#define NORVI_LED1  NORVI_LED_ERROR   // kept for compatibility
#define NORVI_LED2  NORVI_LED_RUN
#define NORVI_PB3   3

#endif /* Pins_Arduino_h */
