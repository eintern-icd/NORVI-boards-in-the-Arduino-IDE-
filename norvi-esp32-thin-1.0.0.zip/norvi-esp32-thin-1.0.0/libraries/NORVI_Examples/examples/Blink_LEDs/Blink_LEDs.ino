/*
  Blink_LEDs - NORVI X1 / X2 / X3 / XN
  Alternates the ERROR and RUN LEDs and reports the two push buttons on Serial (115200).
  The board is checked at start-up:
    1. PCA9536 at 0x41 found  -> LEDs and buttons are on the PCA9536 (standard boards)
    2. otherwise PCA9539 at 0x75 -> LEDs and buttons are on the PCA9539 (newer hardware)
  LEDs are active LOW, buttons read HIGH while pressed. No extra library needed.
*/
#include <Wire.h>

static uint8_t chip;                    // I2C address in use (0 = none found)
static uint8_t inReg, outReg, cfgReg;   // register numbers of that chip
static uint8_t errBit, runBit, btn1Bit, btn2Bit;
static uint8_t outShadow;               // copy of the output register

static bool present(uint8_t addr) {
  Wire.beginTransmission(addr);
  return Wire.endTransmission() == 0;
}

static void writeReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(chip);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

static uint8_t readReg(uint8_t reg) {
  Wire.beginTransmission(chip);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom((int)chip, 1);
  return Wire.available() ? Wire.read() : 0xFF;
}

static void setLeds(bool err, bool run) {      // true = LED on (active LOW)
  uint8_t v = outShadow;
  if (err) v &= ~(1 << errBit); else v |= (1 << errBit);
  if (run) v &= ~(1 << runBit); else v |= (1 << runBit);
  outShadow = v;
  writeReg(outReg, v);
}

void setup() {
  Serial.begin(115200);
  pinMode(NORVI_PORT_RST, OUTPUT);
  digitalWrite(NORVI_PORT_RST, HIGH);          // wake the I/O expanders
  delay(100);
  Wire.begin(SDA, SCL);

  if (present(NORVI_I2C_PCA9536)) {            // 0x41 first
    chip = NORVI_I2C_PCA9536;
    inReg = 0x00; outReg = 0x01; cfgReg = 0x03;
    btn1Bit = 0; errBit = 1; runBit = 2; btn2Bit = 3;
    writeReg(outReg, 0x0F);                    // all high = LEDs off
    writeReg(cfgReg, 0x09);                    // pins 0 and 3 inputs (buttons), 1 and 2 outputs (LEDs)
    outShadow = 0x0F;
    Serial.println("LEDs and buttons on PCA9536 (0x41)");
  } else if (present(NORVI_I2C_PCA9539)) {     // fallback: 0x75
    chip = NORVI_I2C_PCA9539;
    inReg = 0x00; outReg = 0x02; cfgReg = 0x06;          // port 0 registers
    btn1Bit = 1; btn2Bit = 2; errBit = 3; runBit = 4;    // P0_1, P0_2, P0_3, P0_4
    outShadow = readReg(outReg) | (1 << errBit) | (1 << runBit);
    writeReg(outReg, outShadow);               // LEDs off before they become outputs
    writeReg(cfgReg, readReg(cfgReg) & ~((1 << errBit) | (1 << runBit)));   // LED pins = outputs, others untouched
    Serial.println("No PCA9536 at 0x41 - LEDs and buttons on PCA9539 (0x75)");
  } else {
    Serial.println("No PCA9536 (0x41) or PCA9539 (0x75) found - check power and I2C");
  }
}

void loop() {
  static bool pb1Last = false, pb2Last = false;
  static uint32_t lastStep = 0;
  static uint8_t step = 0;

  if (!chip) { delay(2000); Serial.println("No I/O expander found"); return; }

  uint8_t in = readReg(inReg);
  bool pb1 = in & (1 << btn1Bit);
  bool pb2 = in & (1 << btn2Bit);
  if (pb1 != pb1Last) { Serial.println(pb1 ? "PB1 pressed" : "PB1 released"); pb1Last = pb1; }
  if (pb2 != pb2Last) { Serial.println(pb2 ? "PB2 pressed" : "PB2 released"); pb2Last = pb2; }

  if (millis() - lastStep >= 500) {
    lastStep = millis();
    if (step == 0) setLeds(true, false);       // ERROR on, RUN off
    else           setLeds(false, true);       // RUN on, ERROR off
    step ^= 1;
  }
  delay(10);
}
